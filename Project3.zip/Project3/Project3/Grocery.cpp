#include <iostream>
#include <list>
#include <map>
#include <string>
#include <fstream>
#include <limits>
#include <vector>

using namespace std;

void toLower(string& word) {
    for (char& c : word) {
        c = std::tolower(static_cast<unsigned char>(c));
    }
}

//never used. maps are just better for the job 
class Item {
private:
    string itemName;
    int itemQuantity;

public:
    Item(string itemName, int itemQuantity) {
        this->itemName = itemName;
        this->itemQuantity = itemQuantity;
    }
    string getItemName() {
        return this->itemName;
    }
    int getItemQuantity() {
        return this->itemQuantity;
    }
    void incrementItemQuantity() {
        this->itemQuantity++;
    }
    
};

void parseForSearchQuantity(map<string, int> items, string desiredItem) {
    //Convert search text to lowercase
    toLower(desiredItem);
    if (items.find(desiredItem) != items.end()) {
        cout << items[desiredItem] << " " << desiredItem << " have been purchased." << endl << endl;
    }
    else {
        cout << "No " << desiredItem << " have been purchased." << endl << endl;
    }
}

void listItems(map<string, int> &items) {

    cout << endl << "ITEMS" << endl;
    cout << "-----" << endl;

    //loops through items in a map and prints the key (item) followed by the value (item quantity) associated
    for (const auto& pair : items) {
        cout << pair.first << " " << pair.second << endl;
    }
    
}

void histogram(map<string, int> &items) {
    int totalWidth = 60;

    for (const auto& pair : items) {
        //centers the right side of text
        int padding = (60 - pair.first.length());
        cout << string(padding, ' ') << pair.first << ' ';

        //prints a star times the quantity of the item
        for (int i = 0; i < pair.second; i++) {
            cout << '*';
        }
        cout << endl;
    }
}

void instantiateMap(map<string, int>& items) {
    string parsedText;
    ifstream file("frequency.dat");
    
    //loops through each line of text and looks for it in my items map. if it exists then it increments the value (item quantity) associated with it, if it doesnt exist it creates a new key in the map and starts its value at 1
    while (getline(file, parsedText)) {
        toLower(parsedText);
        if (items.find(parsedText) != items.end()) {
            items[parsedText]++;
        }
        else {
            items.insert({ parsedText, 1 });
        }
    }
}

int main() {
    //creates a map to contain items and their quantity
    map<string, int> items;

    string courseOfAction;
    instantiateMap(items);

    //loops until quit is the given course of action, and then quits.
    while (true) {
        cout << "What would you like to do? Please enter: Search, List, Histogram, Quit" << endl;
        cin >> courseOfAction;
        toLower(courseOfAction);
        
        if (courseOfAction == "search") {
            string searchItem;
            cout << "What item would you like?" << endl;
            cin.ignore();
            getline(cin, searchItem);

            //prints item quantity
            parseForSearchQuantity(items, searchItem);
        }
        else if (courseOfAction == "list") {
            listItems(items);
        }
        else if (courseOfAction == "histogram") {
            histogram(items);
        }
        else if (courseOfAction == "quit") {
            exit(EXIT_SUCCESS);
        }
        else {
            //ensures program continues even after incorrect inputs.
            cout << "Invalid Input. Try again." << endl;
        }
    }
    
    return 0;
}